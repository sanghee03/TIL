# STAGE 3 Background -Web

상태: Web Hacking

[Cookie & Session](STAGE%203%20Background%20-Web%2060cb278584b943d29133260ecdcfa1b6/Cookie%20&%20Session%2062d7defb62bf4c11a3928e2ed95799d5.md)

[Mitigation: Same Origin Policy](STAGE%203%20Background%20-Web%2060cb278584b943d29133260ecdcfa1b6/Mitigation%20Same%20Origin%20Policy%20f4e289e63de5425aba5a6e1742a210d9.md)

[Exerciser: Cookie](STAGE%203%20Background%20-Web%2060cb278584b943d29133260ecdcfa1b6/Exerciser%20Cookie%2099f8e2a0f142413c815e1ec2f84db116.md)

[Session-Basic](STAGE%203%20Background%20-Web%2060cb278584b943d29133260ecdcfa1b6/Session-Basic%2099c0b66d7b13458e8bf33cf144718d70.md)