# Tools: Browser DevTools

### 1-1. 개발자 도구

브라우저 개발자 도구(Devtools)는 HTML과 CSS 코드를 브라우저에서 수정하고 결과를 바로 확인할 수 있으며, 자바스크립트 코드를 대상으로 디버거도 제공한다. 서버와 오가는 HTTP 패킷도 상세히 보여주므로 프로토콜 상에서 발생하는 문제도 쉽게 발견할 수 있다. 

개발자 도구가 웹 서비스를 진단하는데 도구인 만큼, 웹 취약점을 이용하려는 공격자에게도 유용하게 사용될 수 있다. 

### 1-2. 개발자 도구 실행

![Untitled](Tools%20Browser%20DevTools%20140ca0cd203e472b9138f19025780dee/Untitled.png)

개발자 도구로 HTML 수정할 수 있음! 

### 1-3. Console

**콘솔**은 프론트엔드의 자바스크립트 코드에서 발생한 각종 메세지를 출력하고, 이용자가 입력한 자바스크립트 코드를 실행도 해주는 도구이다. 

![Untitled](Tools%20Browser%20DevTools%20140ca0cd203e472b9138f19025780dee/Untitled%201.png)

![Untitled](Tools%20Browser%20DevTools%20140ca0cd203e472b9138f19025780dee/Untitled%202.png)

### 페이지 소스 보기  Cmd(**⌘**) + Opt(⌥) + U

### Secret browsing mode Cmd(**⌘**) + shift(**⇧**) + N