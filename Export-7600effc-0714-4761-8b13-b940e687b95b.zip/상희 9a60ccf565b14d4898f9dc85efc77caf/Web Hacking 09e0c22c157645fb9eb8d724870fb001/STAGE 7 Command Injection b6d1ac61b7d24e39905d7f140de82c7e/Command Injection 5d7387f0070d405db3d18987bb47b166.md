# Command Injection

`시스템 함수` : 이미 설치된 소프트웨어들을 쉽게 이용할 수 있다는 장점이 있으나, 함수의 인자를 셀의 명령어로 전달하는 점에서 취약점으로 이어지기도 한다. 

`Command Injection` : 명령어를 실행해주는 함수를 잘못 사용하여 발생하는 취약점으로 이용자의 입력을 시스템 명령어로 실행하게 하는 취약점이다. 명령어를 실행하는 함수에 이용자가 임의의 인자를 전달할 수 있을 때 발생한다. 이용자의 입력을 제대로 검사하지 않으면 임의 명령어가 실행될 수 있다. 이는 리눅스 셀 프로그램이 지원하는 다양한 메타 문자 때문이다. 시스템 함수는 셀 프로그램에 명령어를 전달하여 실행하는데, 셀 프로그램은 다양한 메타 문자를 지원한다. 

→ 개발자는 이용자의 입력을 반드시 검사해야 하며, 되도록 system 함수의 사용을 자제해야 함

ex) 파이썬으로 개발된 웹 애플리케이션에서 입력한 임의 IP에 ping을 전송하고 싶다면 `os.system(“ping [user-input]”)`을, 임의 파일을 읽고 싶다면 `os.system(“cat [user-input]”)` 등의 형태로 시스템 함수를 사용

<메타문자> : 셸 프로그램에서 특수하게 처리하는 문자. `;`를 사용하면 여러 개의 명령어를 순서대로 실행시킬 수 있음.

`&&`, `;`, `|` 등을 사용하면 여러 개의 명령어를 연속으로 실행시킬 수 있다. 따라서 공격자는 메타 문자를 통해 임의 명령어를 실행하여 셸을 획득할 수 있다.

| 메타 문자 | 설명 | Example |
| --- | --- | --- |
| `` | 명령어 치환``안에 들어있는 명령어를 실행한 결과로 치환됩니다. | $ echo `echo theori`theori |
| $() | 명령어 치환$()안에 들어있는 명령어를 실행한 결과로 치환됩니다. 이 문자는 위와 다르게 중복 사용이 가능합니다. (echo $(echo $(echo theori))) | $ echo $(echo theori)theori |
| && | 명령어 연속 실행한 줄에 여러 명령어를 사용하고 싶을 때 사용합니다. 앞 명령어에서 에러가 발생하지 않아야 뒷 명령어를 실행합니다. (Logical And) | $ echo hello && echo theorihellotheori |
| || | 명령어 연속 실행한 줄에 여러 명령어를 사용하고 싶을 때 사용합니다. 앞 명령어에서 에러가 발생해야 뒷 명령어를 실행합니다. (Logical Or) | $ cat / || echo theoricat: /: Is a directorytheori |
| ; | 명령어 구분자한 줄에 여러 명령어를 사용하고 싶을 때 사용합니다. ;은 단순히 명령어를 구분하기 위해 사용하며, 앞 명령어의 에러 유무와 관계 없이 뒷 명령어를 실행합니다. | $ echo hello ; echo theorihellotheori |
| | | 파이프앞 명령어의 결과가 뒷 명령어의 입력으로 들어갑니다. | $ echo id | /bin/shuid=1001(theori) gid=1001(theori) groups=1001(theori) |

Command Injection 실습

```jsx
@app.route('/ping')
def ping():
	ip = request.args.get('ip')
	return os.system(f'ping -c 3 {ip}')
```

Command Injection이 발생하는 예제 코드입니다. 코드를 살펴보면, URL 쿼리를 통해 전달되는 `ip` 값을 ping 명령어의 인자로 전달합니다.

ex)

<메타 문자를 사용해 `id` 명령어를 실행하는 명령줄>

```jsx
$ ping -c 3 1.1.1.1; id
$ ping -c 3 1.1.1.1 && id
$ ping -c 3 1.1.1.1 | id
// ping command is work
        Injected Command: id
        성공하셨습니다!
```

위의 결과와 같이 `id` 명령어를 실행하기 위해서는 메타 문자를 사용해야 한다.