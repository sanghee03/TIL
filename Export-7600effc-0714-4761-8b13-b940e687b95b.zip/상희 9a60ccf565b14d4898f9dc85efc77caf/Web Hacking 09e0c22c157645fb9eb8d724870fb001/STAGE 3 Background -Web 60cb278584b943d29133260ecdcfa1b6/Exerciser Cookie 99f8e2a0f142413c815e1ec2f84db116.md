# Exerciser: Cookie

1. 로그인 정보 확인
    
    ![Untitled](Exerciser%20Cookie%2099f8e2a0f142413c815e1ec2f84db116/Untitled.png)
    
2. guest로 로그인
    
    ![Untitled](Exerciser%20Cookie%2099f8e2a0f142413c815e1ec2f84db116/Untitled%201.png)
    
3. value 값을 admin으로 수정 후 서버 요청
    
    ![Untitled](Exerciser%20Cookie%2099f8e2a0f142413c815e1ec2f84db116/Untitled%202.png)
    
4. flag 값 획득

![Untitled](Exerciser%20Cookie%2099f8e2a0f142413c815e1ec2f84db116/Untitled%203.png)