# STAGE 5 Cross Site Request Forgery

상태: Web Hacking

[ClientSide: CSRF](STAGE%205%20Cross%20Site%20Request%20Forgery%2080291835085e4d7eb6d16e868deba2dd/ClientSide%20CSRF%20ad24697ee38847419de401cdbd06ce3c.md)

[Exercise: CSRF](STAGE%205%20Cross%20Site%20Request%20Forgery%2080291835085e4d7eb6d16e868deba2dd/Exercise%20CSRF%200510611263204b8b9f16965a40da585e.md)

[CSRF-2](STAGE%205%20Cross%20Site%20Request%20Forgery%2080291835085e4d7eb6d16e868deba2dd/CSRF-2%207a7d94cc60ab4800a86e39c54424020b.md)