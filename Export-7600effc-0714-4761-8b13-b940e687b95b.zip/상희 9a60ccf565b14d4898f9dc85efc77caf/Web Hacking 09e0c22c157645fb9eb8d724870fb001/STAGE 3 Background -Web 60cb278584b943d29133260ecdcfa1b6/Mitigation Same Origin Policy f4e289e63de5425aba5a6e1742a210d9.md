# Mitigation: Same Origin Policy

## 동일 출처 정책(Same Origin Policy:SOP) 보안 메커니즘

: 이용자가 웹 서비스에 접속할 때, 브라우저는 해당 웹 서비스에서 사용하는 인증 정보인 쿠키를 HTTP 요청에 포함시켜 전달한다. 

- 오리진 구분 방법
    
    ![Untitled](Mitigation%20Same%20Origin%20Policy%20f4e289e63de5425aba5a6e1742a210d9/Untitled.png)
    

## 교차 출처 리소스 공유(Cross Origin Resource Sharing:CORS)

HTTP 헤더에 기반하여 Cross Origin 간에 리소스를 공유하는 방법이다. 

브라우저는 수신측의 응답이 발신측의 요청과 상응하는지 확인하고, 그때야 비로소 POST 요청을 보내 수신측의 웹 리소스를 요청하는 HTTP 요청을 보낸다. 

## JSON with Padding(JSONP)

`<script>` 태그로 Cross Origin의 데이터를 불러온다. 하지만 `<script>` 태그 내에서는 데이터를 자바스크립트의 코드로 인식하기 때문에 **Callback** 함수를 활용해야 한다. 그러나 현재는 거의 사용 X

- 키워드
    
    ![Untitled](Mitigation%20Same%20Origin%20Policy%20f4e289e63de5425aba5a6e1742a210d9/Untitled%201.png)