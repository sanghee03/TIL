# STAGE 2 Background -Web

상태: Web Hacking

[Background: HTTP/HTTPS](STAGE%202%20Background%20-Web%207a750f1cb3c64a2f95df648c42b71d2c/Background%20HTTP%20HTTPS%20aa45d886ffe149178ca00c9175e31756.md)

[Background: Web](STAGE%202%20Background%20-Web%207a750f1cb3c64a2f95df648c42b71d2c/Background%20Web%2068736ad96a1b4ee297ad3c3f08baf387.md)

[Background: Web Browser](STAGE%202%20Background%20-Web%207a750f1cb3c64a2f95df648c42b71d2c/Background%20Web%20Browser%202a2f357f24d4467eb0036c70daa99e79.md)

[Tools: Browser DevTools](STAGE%202%20Background%20-Web%207a750f1cb3c64a2f95df648c42b71d2c/Tools%20Browser%20DevTools%20140ca0cd203e472b9138f19025780dee.md)