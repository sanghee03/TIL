# Server Side: SSRF

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled.png)

☑️ 웹 개발 언어는 HTTP 요청을 전송하는 라이브러리를 제공하는데, 각 언어별 HTTP 라이브러리는 PHP의 `php-curl`, NodeJS는 `http`, 파이썬은 `urllib`, `requests` 가 있다. 

☑️ 이러한 라이브러리는 서버와 서버간 통신을 위해 사용되기도 한다. 일반적으로 다른 웹 애플리케이션에 존재하는 리소스를 사용하기 위한 목적으로 통신한다. 

☑️ 최근의 웹서비스는 관리 및 코드의 복잡도를 낮추기 위해 **마이크로서비스** 들로  웹 서비스를 구현하는 추세이다! HTTP, GRPC 등을 사용함. 

## ⚠️ **Server-side Request Forgery(SSRF)**

---

☑️ 웹 서비스의 요청을 변조하는 취약점으로, 브라우저가 변조된 요청을 보내는 CSRF와는 다르게 웹 서비스의 권한으로 변조된 요청을 보낼 수 있다.

☑️  웹 서비스는 내부망의 기능을 사용할 때가 있는데, 내부망의 기능은 백오피스 서비스를 예로 들 수 있다. 백오피스 서비스는 자리자 페이지라고도 불리며, 관리자만이 수행할 수 있는 모든 기능을 구현한 서비스이다. 이 서비스는 외부에서 접근할 수 없는 내부망에 위치해야 한다. 

☑️ 웹 서비스는 의심스러운 행위를 탐지하고 실시간으로 대응하기 위해 백오피스의 기능을 실행할 수 있다. 즉, 웹 서비스는 외부에서 직접 접근할 수 없는 내부망 서비스와 통신할 수 있다. 

☑️ 만약 공격자가 SSRF 취약점을 통해 웹 서비스의 권한으로 요청을 보낼 수 있다면 공격자는 외부에서 간접적으로 내부망 서비스를 이용할 수 있고, 이는 곧 기업에 막대한 피해를 입힐 수 있다. 

☑️ 웹 서비스가 보내는 요청을 변조하기 위해서는 요청 내에 이용자의 입력값이 포함되어야 한다. 입력값이 포함되는 예시로는 웹 서비스가 이용자가 입력한 URL에 요청을 보내거나 요청을 보낼 URL에 이용자 번호와 같은 내용이 사용되는 경우, 그리고 이용자가 입력한 값이 HTTP Body에 포함되는 경우로 나눠볼 수 있습니다.

### 🔎**분석(**이용자가 입력한 URL에 요청을 보내는 경우)

Figure 1. 이용자가 입력한 URL에 요청을 보내는 경우 예시 코드 

```python
# pip3 install flask requests # 파이썬 flask, requests 라이브러리를 설치하는 명령입니다.
# python3 main.py # 파이썬 코드를 실행하는 명령입니다.
from flask import Flask, request
import requests
app = Flask(__name__)
@app.route("/image_downloader")
def image_downloader():
    # 이용자가 입력한 URL에 HTTP 요청을 보내고 응답을 반환하는 페이지 입니다.
    image_url = request.args.get("image_url", "") # URL 파라미터에서 image_url 값을 가져옵니다.
    response = requests.get(image_url) # requests 라이브러리를 사용해서 image_url URL에 HTTP GET 메소드 요청을 보내고 결과를 response에 저장합니다.
    return ( # 아래의 3가지 정보를 반환합니다.
        response.content, # HTTP 응답으로 온 데이터
        200, # HTTP 응답 코드
        {"Content-Type": response.headers.get("Content-Type", "")}, # HTTP 응답으로 온 헤더 중 Content-Type(응답 내용의 타입)
    )
@app.route("/request_info")
def request_info():
    # 접속한 브라우저(User-Agent)의 정보를 출력하는 페이지 입니다.
    return request.user_agent.string
app.run(host="127.0.0.1", port=8000)
```

### 첫번째 엔드포인트, **image_downloader**

이용자가 입력한 `image_url`을  `requests.get` 함수를 사용해 GET 메소드로 HTTP 요청을 보내고 응답을 반환합니다. 브라우저에서 다음과 같은 URL을 입력하면 드림핵 페이지에 요청을 보내고 응답을 반환합니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%201.png)

### **두번째 엔드포인트, request_info**

웹 페이지에 접속한 브라우저의 정보(User-Agent)를 반환합니다. 브라우저를 통해 해당 엔드포인트에 접근하면 접속하는데에 사용된 브라우저의 정보가 출력됩니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%202.png)

### 문제점

---

image_downloader 엔드포인트의 `image_url`에 request_info 엔드포인트 경로를 입력해보면 

```python
http://127.0.0.1:8000/image_downloader?image_url=**http://127.0.0.1:8000/request_info**
```

위 경로에 접속하면 **image_downloader**에서는 `http://127.0.0.1:8000/request_info` URL에 HTTP 요청을 보내고 응답을 반환합니다. 반환한 값을 확인해보면 브라우저로 **request_info** 엔드포인트에 접속했을 때와 다르게 브라우저 정보가 `python-requests/2.11.1`인 것을 확인할 수 있습니다.

접속한 브라우저 정보로 `python-requests` 가 출력된 이유는 웹 서비스에서 HTTP 요청을 보냈기 때문입니다. 이처럼 이용자가 웹 서비스에서 사용하는 **마이크로서비스의 API 주소(http://127.0.0.1:8000/request_info)**를 알아내고, `image_url`에 주소를 전달하면 외부에서 직접 접근할 수 없는 마이크로서비스의 기능을 임의로 사용할 수 있습니다.

### 🔎 **분석(웹 서비스의 요청 URL에 이용자의 입력값이 포함되는**  경우)

---

Figure 2. 웹 서비스의 요청 URL에 이용자의 입력값이 포함되는 경우 예시 코드

```python
INTERNAL_API = "http://api.internal/"
# INTERNAL_API = "http://172.17.0.3/"
@app.route("/v1/api/user/information")
def user_info(): #첫번째 엔드포인트
	user_idx = request.args.get("user_idx", "")
	response = requests.get(f"{INTERNAL_API}/user/{user_idx}")
@app.route("/v1/api/user/search")
def user_search(): #두번째 엔드포인트
	user_name = request.args.get("user_name", "")
	user_type = "public"
	response = requests.get(f"{INTERNAL_API}/user/search?user_name={user_name}&user_type={user_type}")
```

### 첫번째 엔드포인트, user_info

이용자가 전달한 `user_idx` 값을 내부 API의 URL 경로로 사용합니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%203.png)

이용자가 위와 같이 `user_idx` 를 1로 설정하고 요청을 보내면 웹 서비스는 다음과 같은 주소에 요청을 보냅니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%204.png)

### 두번째 엔드포인트, user_search

이용자가 전달한 `user_name`값을 내부 API의 쿼리로 사용합니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%205.png)

이용자가 위와 같이 `user_name`을 “hello”로 설정하고 요청을 보내면 웹 서비스는 다음과 같은 주소에 요청을 보냅니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%206.png)

### 문제점

---

웹 서비스가 요청하는 URL에 이용자의 입력값이 포함되면 요청을 변조할 수 있습니다. 이용자의 입력값 중 URL의 구성 요소 문자를 삽입하면 API 경로를 조작할 수 있습니다. 

예를 들어, 예시 코드의 `user_info` ****함수에서 `user_idx`에 `../search`
를 입력할 경우 웹 서비스는 다음과 같은 URL에 요청을 보냅니다.

![Untitled](Server%20Side%20SSRF%2075f25122a15c473eb49efe8860a25ba1/Untitled%207.png)

`..`는 상위 경로로 이동하기 위한 구분자로, 해당 문자로 요청을 보내는 경로를 조작할 수 있습니다. 

☑️  해당 취약점은 경로를 변조한다는 의미에서 **Path Traversal** 이라고 불립니다.